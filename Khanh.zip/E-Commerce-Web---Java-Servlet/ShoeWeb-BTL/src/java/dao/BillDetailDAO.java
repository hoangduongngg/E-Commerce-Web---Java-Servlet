/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import context.DBContext;
import entity.Account;
import entity.Product;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author khanh
 */
public class BillDetailDAO extends DAO{

public List<BillDetail> getAllAccount() throws ClassNotFoundException{
	List<BillDetail> list = new ArrayList<>();
	String query = "select * from billdetail";
	try {
	    conn = new DBContext().getConnection();//mo ket noi voi sql
	    ps = conn.prepareStatement(query);
	    rs = ps.executeQuery();
	    while (rs.next()) {
		list.add(new BillDetail(rs.getInt(1),
			rs.getString(2),
			rs.getInt(3),
			rs.getDouble(4)));
	    }
	} catch (Exception e) {
	}
	return list;
    }

// Sign Up: Them Account moi vao Database
    public void insert(String nameProduct, int quantity, double price) throws ClassNotFoundException{
	String query = "insert into billdetail (nameproduct, quantity, totalprice)\n"
		+ "values (?, ?, ?)";
	try {
	    conn = new DBContext().getConnection();//mo ket noi voi sql
	    ps = conn.prepareStatement(query);
	    ps.setString(1, nameProduct);
	    ps.setInt(2, quantity);
            ps.setDouble(3, price * quantity);

//            rs = ps.executeQuery(); Khi chay cau lech tren khong co result tra ve, chi Insert
	    ps.executeUpdate();
	} catch (Exception e) {
	}
    }

    public void update(String nameProduct, int quantity, double price) throws ClassNotFoundException{
//chỉ sửa số lượng nếu không muốn mua sản phẩm này nữa phải xóa
	String query = "update billdetail set quantity = '" + quantity + "', totalprice = '" + price * quantity + "' where nameproduct = '" + nameProduct + "'";
	try {
	    conn = new DBContext().getConnection();//mo ket noi voi sql
	    ps = conn.prepareStatement(query);

//            rs = ps.executeQuery(); Khi chay cau lech tren khong co result tra ve, chi Update
	    ps.executeUpdate();
	} catch (Exception e) {
	}
    }

    public void delete(String nameProduct) throws ClassNotFoundException{
	String query = "delete from billdetail where nameproduct = '" + nameProduct + "'";
	try {
	    conn = new DBContext().getConnection();//mo ket noi voi sql
	    ps = conn.prepareStatement(query);
//            rs = ps.executeQuery(); Khi chay cau lech tren khong co result tra ve, chi Update
	    ps.executeUpdate();
	} catch (Exception e) {
	}
    }
}
