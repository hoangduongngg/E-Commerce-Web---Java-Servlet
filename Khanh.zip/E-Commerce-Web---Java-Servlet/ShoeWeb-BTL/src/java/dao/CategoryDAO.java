/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import context.DBContext;
import entity.Category;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author hoangduongngg
 */
public class CategoryDAO extends DAO{
    // Lay ra tat ca danh muc
    public List<Category> getAllCategory() throws ClassNotFoundException{
        List<Category> list = new ArrayList<>();
        String query = "select * from Category";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Category(rs.getInt(1),
                        rs.getString(2)));
            }
        } catch (Exception e) {
        }
        return list;
    }
    public static void main(String[] args) throws ClassNotFoundException {
        CategoryDAO aO = new CategoryDAO();
        List<Category> l = aO.getAllCategory();
        for (Category category : l) {
            System.out.println(category.getCname());
        }
    }
    
}