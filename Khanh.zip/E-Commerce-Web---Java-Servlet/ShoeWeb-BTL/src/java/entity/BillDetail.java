/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author khanh
 */
public class BillDetail {

    private int id;
    private String nameProduct;
    private int quantity;
    private double totalPrice;

    public BillDetail(int id, String nameProduct, int quantity, double price) {
        this.id = id;
        this.nameProduct = nameProduct;
        this.quantity = quantity;
        this.totalPrice = sumPrice(quantity, price);
    }

    private double sumPrice(int quantity, double price) {
        return quantity * price;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNameProduct() {
        return nameProduct;
    }

    public void setNameProduct(String nameProduct) {
        this.nameProduct = nameProduct;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

}
